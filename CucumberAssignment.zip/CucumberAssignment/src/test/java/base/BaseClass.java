package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class BaseClass implements Wrappers {
	
	
	
	public static RemoteWebDriver driver;

	@Override
	public void invokeApp(String browser, String url) {
		
		try {
			if(browser.equals("chrome")) 
			{
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				 driver= new ChromeDriver();
			}	
			driver.manage().window().maximize();
			driver.get(url);
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
			
			System.out.println("Browser launched successfully");
			
		} catch (SessionNotCreatedException e) {
			System.err.println("Session not created");
		} catch (WebDriverException e) {
			System.err.println("Browser Not launched successfully");
			
		}
		
	}

	@Override
	public void enterValue(WebElement element, String data) {
		// TODO Auto-generated method stub
		
		try {
			element.sendKeys(data);
			System.out.println("Able to give text");
			
		} catch (NoSuchElementException e) {
			System.err.println("Not able to find in the DOM");
		} catch (ElementNotInteractableException e) {
			System.err.println("Element is not able to interactableimn DOM");
		} catch (StaleElementReferenceException e) {
			System.err.println("getting No longer in staleElement");
		} catch (WebDriverException e) {
			System.err.println("Super exception ");
			
		}
		
	}

	@Override
	public void clickElement(WebElement element) {
		// TODO Auto-generated method stub
	
		try {
			element.click();
			System.out.println("Clicked Successfully");
			
		} catch (NoSuchElementException e) {
			System.err.println("session not created");
		} catch (ElementClickInterceptedException e) {
			System.err.println("session not created");
		} catch (WebDriverException e) {
			System.err.println("session not created");
			
		}
		
		
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		
		String s1=driver.getTitle();
		try {
			String obj= driver.getTitle();
			System.out.println("Webpage Title");
		} catch (NoSuchElementException e) {
			System.err.println("Title locator incoorect");
		} catch (StaleElementReferenceException e) {
			System.err.println("Title locator incoorect");
		} catch (WebDriverException e) {
			System.err.println("Title locator incoorect");
		}
		
		return s1;
	}

	@Override
	public String getText(WebElement element) {
		// TODO Auto-generated method stub
	
		String s1=null;
		try {
			String obj = element.getText();
			System.out.println("Text value displayed");
		} catch (NoSuchElementException e) {
			System.err.println("getText in Correct value");
		} catch (StaleElementReferenceException e) {
			System.err.println("getText in Correct value");
		} catch (WebDriverException e) {
			System.err.println("getText in Correct value");
		}
		
		return s1;	
	}

	@Override
	public void selectByIndex(WebElement element, int indexValue) {
		// TODO Auto-generated method stub
		
		try {
			Select s1= new Select(element);
			s1.selectByIndex(indexValue);
			System.out.println("dropdown");
		} catch (StaleElementReferenceException e) {
			System.err.println("dropdown values not correct");
		} catch (NoSuchElementException e) {
			System.err.println("dropdown values not correct");
		}  catch (WebDriverException e) {
			System.err.println("dropdown values not correct");
		}
			
	}

	@Override
	public void selectByVisibleText(WebElement element, String visibleText) {
		// TODO Auto-generated method stub
		
		try {
			Select s1= new Select(element);
			s1.selectByVisibleText(visibleText);
			System.out.println("dropdown");
		} catch (NoSuchElementException e) {
			System.err.println("dropdown values not correct");
		} catch (StaleElementReferenceException e) {
			System.err.println("dropdown values not correct");
		} catch (WebDriverException e) {
			System.err.println("dropdown values not correct");
		}	
		
	}

	@Override
	public void selectByValue(WebElement element, String value) {
		// TODO Auto-generated method stub
		
			try {
				Select s1= new Select(element);
				s1.selectByValue(value);
				System.out.println("dropdown");
			} catch (NoSuchElementException e) {
				System.err.println("dropdown values not correct");
			} catch (StaleElementReferenceException e) {
				System.err.println("dropdown values not correct");
			} catch (WebDriverException e) {
				System.err.println("dropdown values not correct in value");
			}
		
	}
	
	

	@Override
	public void swithToParentWindow() {
		// TODO Auto-generated method stub
		
		try {
			Set<String> text=  driver.getWindowHandles();
			Iterator<String> obj= text.iterator();
			String parentSessionId = obj.next();
			driver.switchTo().window(parentSessionId);
			System.out.println("window will display");
		} catch (NoSuchWindowException e) {
			System.err.println("window is not correct");
		}
		
		catch (StaleElementReferenceException e) {
			System.err.println("window is not correct");
		}
		catch (NoSuchElementException e) {
			System.err.println("window is not correct");
		}
		catch (WebDriverException e) {
			System.err.println("window is not correct");
		}
	
	}
	
	public void clickElementUsingJavascript(WebElement element) 
	{
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click();", element);
			System.out.println("Click the element");
		} catch (Exception e) {
			System.err.println("unable to click the element");
		}
		
		
	}

	@Override
	public void swithToWindow() {
		// TODO Auto-generated method stub
		
		
	
		try {
			Set<String> prod =driver.getWindowHandles();
			Iterator<String> pass =prod.iterator();
			String parentSesssionId =pass.next();
			String childsessionID = pass.next();
			driver.switchTo().window(childsessionID);
			System.out.println("window will display");
		} catch (NoSuchWindowException e) {
			System.err.println("window is not correct");
		}catch (StaleElementReferenceException e) {
				System.err.println("window is not correct");
			}catch (NoSuchElementException e) {
				System.err.println("window is not correct");
			}catch (WebDriverException e) {
				System.err.println("window is not correct");
			}
		
	}

	@Override
	public void swithToFrame(String framename) {
		// TODO Auto-generated method stub
		
		try {
			driver.switchTo().frame(framename);
			System.out.println("Frame page");
		} catch (NoSuchFrameException e) {
			System.err.println("Frame page is not correct");
		}
		catch (StaleElementReferenceException e) {
			System.err.println("Frame page is not correct");
		} catch (NoSuchElementException e) {
			System.err.println("Frame page is not correct");
		} catch (WebDriverException e) {
			System.err.println("Frame page is not correct");
		}
		
		
		
	}

	@Override
	public void acceptAlert() {
		// TODO Auto-generated method stub
		
		try {
			driver.switchTo().alert().accept();
			System.out.println("Alert ");
		} catch (NoAlertPresentException e) {
			System.err.println("Alert is getting error");
		} catch (StaleElementReferenceException e) {
			System.err.println("Alert is getting error");
		} catch (NoSuchElementException e) {
			System.err.println("Alert is getting error");
		}
		
		
		
	}

	@Override
	public void dismissAlert() {
		// TODO Auto-generated method stub
		driver.switchTo().alert().dismiss();
		
		try {
			driver.switchTo().alert().dismiss();
			System.out.println("Alert ");
		} catch (NoAlertPresentException e) {
			System.err.println("Alert is getting error");
		} catch (StaleElementReferenceException e) {
			System.err.println("Alert is getting error");
		} catch (NoSuchElementException e) {
			System.err.println("Alert is getting error");
		}
		
	}

	@Override
	public String getAlertText() {
		// TODO Auto-generated method stub
		
		
		String s1=null;
		try {
			String obj= driver.switchTo().alert().getText();
			System.out.println("Alert name is displaying");
		} catch (NoSuchElementException e) {
			System.err.println("Alert exception");
		} catch (NoAlertPresentException e) {
			System.err.println("Alert exception");
		}
		return s1;
	}

	@Override
	public void sendInfoToAlert(String textValue) {
		// TODO Auto-generated method stub
		driver.switchTo().alert().sendKeys(textValue);
		
		try {
			driver.switchTo().alert().sendKeys(textValue);
			System.out.println("Entering value in the Alert box");
		} catch (NoAlertPresentException e) {
			System.err.println("Alert not correct");
		} catch (StaleElementReferenceException e) {
			System.err.println("Alert not correct");
		} catch (NoSuchElementException e) {
			System.err.println("Alert not correct");
		}
		
		
	}

	@Override
	public void closeBrowser() {
		// TODO Auto-generated method stub
		driver.close();
		
	}

	@Override
	public void closeAllBrowser() {
		// TODO Auto-generated method stub
		driver.quit();
		
	}

	@Override
	public void takeSnap() throws IOException {
		// TODO Auto-generated method stub
		
		File tmp= driver.getScreenshotAs(OutputType.FILE);
		File dest= new File("./screenshots/one.png");
		FileUtils.copyFile(tmp, dest);
		
		
		
		
		
		
	}

	@Override
	public void tabOutField(WebElement element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void scrollPageDown() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getAttributeBy(WebElement element) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void loadSubjects() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void unloadSubjects() {
		// TODO Auto-generated method stub
		
	}

	
	
}

	