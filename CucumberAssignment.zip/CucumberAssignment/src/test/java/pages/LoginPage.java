package pages;

import javax.xml.xpath.XPath;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class LoginPage  extends BaseClass{
	
	public LoginPage(RemoteWebDriver driver)
	{
		this.driver= driver;
		PageFactory.initElements(driver,this);
	}
	
	
	@FindBy(xpath = "//input[@id='okta-signin-username']")
	WebElement username;
	
	@FindBy(xpath = "//input[@id='okta-signin-password']")
	WebElement password;
	
	@FindBy(xpath = "//input[@id='okta-signin-submit']")
	WebElement LoginButton;
	
	@FindBy(xpath = "//input[@type='submit']")
	WebElement sendpush;
	
	
	//Actions
	
	public LoginPage EnterUsername(String usernamevalue)
	{
		enterValue(username, usernamevalue);
		return this;
	}
	
	public LoginPage EnterPassword(String passwordvalue)
	{
		enterValue(password, passwordvalue);
		return this;
	}
	
	public LoginUser Clickloginbutton()
	{
		clickElement(LoginButton);
		return new LoginUser();
	}
	
	public LoginUser Pushbutton()
	{
		clickElement(sendpush);
		return new LoginUser();
		
	}

}
