package pages;

public class LoginUser {

}
