package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class ContextSelectionPage extends BaseClass {
	
	public ContextSelectionPage(RemoteWebDriver driver) 

	{
		this.driver= driver;
		PageFactory.initElements(driver, this);
		
	}
	
	
	@FindBy(xpath = "  //*[@id=\"fx-gn-role-dropdown-SG\"]")
	WebElement countrydrpdown;
	
	@FindBy(xpath = "//*[@id=\"fx-gn-carrier-FEDEX\"]")
	WebElement fedex;
	
	@FindBy(id = "btnContextSelection")
	WebElement continueButton;
	
	@FindBy(xpath = "//span[@id='tools']")
	WebElement selectIcon;
	
	
	//Actions
	
	public ContextSelectionPage countrydrpdown(String value)
	{
		selectByValue(countrydrpdown, value);
		return this;
	}
	
	public ContextSelectionPage clickfedex()
	{
		clickElement(fedex);
		return this;
		
	}
	
	public HomePage clickElementUsingJavascriptcontinueButton()
	{
		clickElementUsingJavascript(continueButton);
		return new HomePage(driver);
	}
	
	public ContextSelectionPage ClickIcon()
	{
		clickElement(selectIcon);
		return this;
	}
	
	

}
