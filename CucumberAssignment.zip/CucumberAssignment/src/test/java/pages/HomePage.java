package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class HomePage extends BaseClass{
	public HomePage(RemoteWebDriver driver)
	{
		this.driver= driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(id = "okta-signin-submit")
	WebElement loginMenu;
	
	@FindBy(xpath = "//input[@type='submit']")
	WebElement sendPush;
	
	//Actions
	
	public LoginPage clicklogin()
	{
		clickElement(loginMenu);
		return new LoginPage(driver);
	}
	
	public LoginPage clickpush()
	{
		clickElement(sendPush);
		return new LoginPage(driver);
	}

}
