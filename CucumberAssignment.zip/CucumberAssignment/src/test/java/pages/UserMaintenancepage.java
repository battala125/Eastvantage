package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class UserMaintenancepage extends BaseClass {
	
	public UserMaintenancepage(RemoteWebDriver driver) 

	{
		this.driver= driver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath = "//button[@id='USER_ROLE_MAINTENANCE']/span[2]")
	WebElement usermaintenance;
	
	@FindBy(xpath = "//input[@id='fx-gn-user-role-search-userId']")
	WebElement enterLDAPId;
	
	
	//Actions
	
	
	public UserMaintenancepage clickusermaintence()
	{
		clickElement(usermaintenance);
		return this;
	}
	
	public UserMaintenancepage EnterLDAPId(String userId)
	{
		enterValue(enterLDAPId, userId);
		return this;
	}
	
	
	

}
