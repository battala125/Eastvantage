package stepDefinition;

import static org.testng.Assert.assertEquals;

import base.BaseClass;
import io.cucumber.java.en.Then;
import pages.UserMaintenancepage;

public class UserMaintenance extends BaseClass {
	
	public UserMaintenancepage userclick;
	public UserMaintenancepage enterId;
	
	
	@Then("user click user maintenance icon")
	public void user_click_user_maintenance_icon() {
		
		userclick= new UserMaintenancepage(driver);
		userclick.clickusermaintence();
	   
	}
	
	@Then("search for user in maintenance")
	public void search_for_user_in_maintenance() {
		
		enterId= new UserMaintenancepage(driver);
		enterId.EnterLDAPId("4877776");
	 
	}
	
	@Then("Validate the page Title")
	public void validate_the_page_title() {
		
		String name= getTitle();
		System.out.println(name);
		String expectedTitle= name;
		assertEquals(expectedTitle, name);
		System.out.println(expectedTitle);
		
		
	   
	}

}
