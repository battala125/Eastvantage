package stepDefinition;

import java.time.Duration;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.ContextSelectionPage;
import pages.HomePage;
import pages.LoginPage;

public class UserLogin extends BaseClass {
	
	public HomePage homepage;
	public LoginPage loginpage;
	public ContextSelectionPage contextselectionpage;
	public ContextSelectionPage contextclick;
	
	@Given("the user in homepage of the application")
	public void the_user_in_homepage_of_the_application() {
		
		invokeApp("chrome", "https://accs-gemini-ui-release.app.singdev1.paas.fedex.com/dashboard");
		homepage = new HomePage(driver);
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	    
	}

	@Then("user enter login details")
	public void user_enter_login_details() {
		
		loginpage= homepage.clicklogin();
		loginpage.EnterUsername("4877776")
		.EnterPassword("29ZsvyAbm");
	    
	}

	@Then("user click on login button")
	public void user_click_on_login_button() throws InterruptedException {
		
		loginpage.Clickloginbutton();
		Thread.sleep(5000);
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		
	   
	}
	
	@Then("user click the send push button")
	public void user_click_the_send_push_button() {
		
		loginpage= homepage.clickpush();
	    loginpage.Pushbutton();
	}
	
	@Then("user select contextmenu")
	public void user_select_contextmenu() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		 contextselectionpage = new ContextSelectionPage(driver);
		
//		contextselectionpage.countrydrpdown("accs_broker-lead-dev_sg_sin_app83");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		
		contextselectionpage.countrydrpdown("accs_broker-lead-dev_sg_sin_app83");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		contextselectionpage.clickfedex();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		contextselectionpage.clickElementUsingJavascriptcontinueButton();
		
	   
	}
	
	@Then("user click setting icon")
	public void user_click_setting_icon() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		contextclick = new ContextSelectionPage(driver);
		contextclick.ClickIcon();
		
		
	   
	}

	@Then("validate the success message")
	public void validate_the_success_message() {
	    
	}

}
